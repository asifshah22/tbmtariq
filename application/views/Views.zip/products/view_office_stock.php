

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Manage
      <small>Office Stock</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Office Stock</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <!-- Small boxes (Stat box) -->
    <div class="row">
      <div class="col-md-12 col-xs-12">
        <?php if(in_array('printOfficeStock', $user_permission)): ?>
          <a title="Print Stock Items" target="__blank" href="<?php base_url() ?>print_office_stock_items" class="btn btn-info" id="print">
            <span class="glyphicon glyphicon-print"></span>
          </a>

          <br /> <br />
        <?php endif; ?>
        
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">Office Stock</h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            <table id="manageTable" class="table table-bordered table-hover">
              <thead>
              <tr>
                <th width="8">#</th>
                <th width="23%" style="color:#3c8dbc">Category</th>
                <th width="23%" style="color:#3c8dbc">Item</th>
                <th width="23%" style="color:#3c8dbc">Unit</th>
                <th width="23%" style="color:#3c8dbc">
                  Quantity &nbsp;<a href="#" data-toggle="tooltip" title="Quantity without units are shown with other!"><i class="fa fa-question-circle"></i></a>
                </th>
              </tr>
              </thead>

            </table>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- col-md-12 -->
    </div>
    <!-- /.row -->
    

  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->


<script type="text/javascript">
var manageTable;
var base_url = "<?php echo base_url(); ?>";

$(document).ready(function() {

  $("#mainStockNav").addClass('active');
  $("#viewOfficeStockNav").addClass('active');

  // initialize the datatable 
  manageTable = $('#manageTable').DataTable({
    'ajax': base_url + 'index.php/Product/fetchOfficeStockData',
    'order': [],
    "lengthMenu": [[20, 50, 100, -1], [20, 50, 100, "All"]]
  });

});

</script>
