<?php date_default_timezone_set("Asia/Karachi"); ?>

<div class="content-wrapper">
  <section class="content-header">
    <h1>
      Purchase Order
      <small>Create</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Purchase Order</li>
    </ol>
  </section>

  <section class="content">
    <div class="row">
      <div class="col-md-12 col-xs-12">
        <div id="messages"></div>

        <?php if($this->session->flashdata('success')): ?>
          <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo $this->session->flashdata('success'); ?>
          </div>
        <?php elseif($this->session->flashdata('error')): ?>
          <div class="alert alert-error alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <?php echo $this->session->flashdata('error'); ?>
          </div>
        <?php endif; ?>

        <div class="box">
          <div class="box-header">
            <h3 class="box-title">Purchase Order Form</h3>
          </div>
          <form role="form" action="<?php echo base_url()?>index.php/Purchase_order/create" method="post" class="form-horizontal" id="purchaseOrderForm">
            <div class="box-body">
              <div class="form-group">
                <label class="col-sm-2 control-label">Vendor</label>
                <div class="col-sm-10">
                  <select class="form-control" name="vendor_id" required>
                    <option value="">Select Vendor</option>
                    <?php foreach ($vendor_data as $value): ?>
                      <option value="<?php echo $value['id']; ?>">
                        <?php echo $value['first_name'].' '.$value['last_name']; ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 control-label">PO Number</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" name="po_number" required>
                </div>

                <label class="col-sm-2 control-label">PO Date</label>
                <div class="col-sm-4">
                  <input type="date" class="form-control" name="po_date" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 control-label">Contact Person</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" name="contact_person">
                </div>

                <label class="col-sm-2 control-label">Contact No</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" name="contact_no">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 control-label">Terms of Payment</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" name="terms_of_payment">
                </div>

                <label class="col-sm-2 control-label">Delivery</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" name="delivery">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-2 control-label">Remarks</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="remarks">
                </div>
              </div>

              <hr>

              <div class="table-responsive">
                <table class="table table-bordered" id="po_items_table">
                  <thead>
                    <tr>
                      <th style="width:4%">S#</th>
                      <th>Parts Name</th>
                      <th>Model</th>
                      <th style="width:8%">Qty</th>
                      <th style="width:8%">Unit</th>
                      <th style="width:10%">Rate</th>
                      <th style="width:12%">Amount</th>
                      <th>Remarks</th>
                      <th style="width:6%">
                        <button type="button" id="add_row" class="btn btn-default"><i class="fa fa-plus"></i></button>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr id="row_1">
                      <td>1</td>
                      <td><input type="text" name="part_name[]" class="form-control" required></td>
                      <td><input type="text" name="model[]" class="form-control"></td>
                      <td><input type="number" name="qty[]" class="form-control qty" min="0" step="0.01"></td>
                      <td><input type="text" name="unit[]" class="form-control"></td>
                      <td><input type="number" name="rate[]" class="form-control rate" min="0" step="0.01"></td>
                      <td><input type="number" name="amount[]" class="form-control amount" min="0" step="0.01" readonly></td>
                      <td><input type="text" name="item_remarks[]" class="form-control"></td>
                      <td><button type="button" class="btn btn-default remove_row" data-row="1"><i class="fa fa-minus"></i></button></td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div class="row">
                <div class="col-sm-6"></div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <label class="col-sm-4 control-label">Total Amount</label>
                    <div class="col-sm-8">
                      <input type="number" class="form-control" name="total_amount" id="total_amount" readonly>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-4 control-label">Sales Tax %</label>
                    <div class="col-sm-8">
                      <input type="number" class="form-control" name="sales_tax_percent" id="sales_tax_percent" value="18" min="0" step="0.01">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-4 control-label">Sales Tax Amount</label>
                    <div class="col-sm-8">
                      <input type="number" class="form-control" name="sales_tax_amount" id="sales_tax_amount" readonly>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-4 control-label">Grand Total</label>
                    <div class="col-sm-8">
                      <input type="number" class="form-control" name="grand_total" id="grand_total" readonly>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="box-footer">
              <button type="submit" class="btn btn-primary">Save & Print</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
</div>

<script>
  (function() {
    var rowCount = 1;

    function recalcRow(row) {
      var qty = parseFloat(row.find('.qty').val()) || 0;
      var rate = parseFloat(row.find('.rate').val()) || 0;
      var amount = qty * rate;
      row.find('.amount').val(amount.toFixed(2));
    }

    function recalcTotals() {
      var total = 0;
      $('#po_items_table .amount').each(function() {
        var val = parseFloat($(this).val()) || 0;
        total += val;
      });
      $('#total_amount').val(total.toFixed(2));

      var taxPercent = parseFloat($('#sales_tax_percent').val()) || 0;
      var taxAmount = (total * taxPercent) / 100;
      $('#sales_tax_amount').val(taxAmount.toFixed(2));

      var grand = total + taxAmount;
      $('#grand_total').val(grand.toFixed(2));
    }

    $('#add_row').on('click', function() {
      rowCount++;
      var row = '<tr id="row_' + rowCount + '">' +
        '<td>' + rowCount + '</td>' +
        '<td><input type="text" name="part_name[]" class="form-control" required></td>' +
        '<td><input type="text" name="model[]" class="form-control"></td>' +
        '<td><input type="number" name="qty[]" class="form-control qty" min="0" step="0.01"></td>' +
        '<td><input type="text" name="unit[]" class="form-control"></td>' +
        '<td><input type="number" name="rate[]" class="form-control rate" min="0" step="0.01"></td>' +
        '<td><input type="number" name="amount[]" class="form-control amount" min="0" step="0.01" readonly></td>' +
        '<td><input type="text" name="item_remarks[]" class="form-control"></td>' +
        '<td><button type="button" class="btn btn-default remove_row" data-row="' + rowCount + '"><i class="fa fa-minus"></i></button></td>' +
      '</tr>';
      $('#po_items_table tbody').append(row);
    });

    $('#po_items_table').on('click', '.remove_row', function() {
      if ($('#po_items_table tbody tr').length === 1) {
        return;
      }
      var rowId = $(this).data('row');
      $('#row_' + rowId).remove();
      recalcTotals();
    });

    $('#po_items_table').on('input', '.qty, .rate', function() {
      var row = $(this).closest('tr');
      recalcRow(row);
      recalcTotals();
    });

    $('#sales_tax_percent').on('input', function() {
      recalcTotals();
    });

    $('#mainPurchasingNav').addClass('menu-open');
    $('#purchaseOrderNav').addClass('active');
  })();
</script>
